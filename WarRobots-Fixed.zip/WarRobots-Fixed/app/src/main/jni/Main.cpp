#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "Menu.h"
#include <SOCKET/client.h>
#include <SOCKET/IncludeClient.h>
ESP espOverlay;

bool feature1, feature2, featureHookToggle, Health;
int sliderValue = 1, level = 0;

enum f {
    f1 = 4,
    f2 = 5,
    f3 = 6,
    f4 = 7,
    f5 = 8,
    f6 = 9,
    f7 = 10,
    f8 = 11,
    f9 = 12,
    f10 = 13,
};


//JNI calls
extern "C" {

    // Do not change or translate the first text unless you know what you are doing
    // Assigning feature numbers is optional. Without it, it will automatically count for you, starting from 0
    // Assigned feature numbers can be like any numbers 1,3,200,10... instead in order 0,1,2,3,4,5...
    // ButtonLink, Category, RichTextView and RichWebView is not counted. They can't have feature number assigned
    // Toggle, ButtonOnOff and Checkbox can be switched on by default, if you add True_. Example: CheckBox_True_The Check Box
    // To learn HTML, go to this page: https://www.w3schools.com/

    JNIEXPORT jobjectArray
    JNICALL
    Java_uk_lgl_modmenu_FloatingModMenuService_getFeatureList(JNIEnv *env, jobject context) {
        jobjectArray ret;

        //Toasts added here so it's harder to remove it
        MakeToast(env, context, OBFUSCATE("Anodize Mods - War Robots"), Toast::LENGTH_LONG);

        const char *features[] = {

            // ── MOVEMENT ──────────────────────────────────────────────
            OBFUSCATE("Category_MOVEMENT"),
            OBFUSCATE("CheckBox_SpeedHack"),
            OBFUSCATE("CheckBox_Disable Gravity"),
            OBFUSCATE("CheckBox_Noclip"),
            OBFUSCATE("CheckBox_Multiple Jump"),
            OBFUSCATE("CheckBox_No Jump"),
            OBFUSCATE("CheckBox_Super Jump"),

            // ── ABILITIES ─────────────────────────────────────────────
            OBFUSCATE("Category_ABILITIES"),
            OBFUSCATE("CheckBox_Infinite Robot Skill 1"),
            OBFUSCATE("CheckBox_No Duration Robot Skill 1"),
            OBFUSCATE("CheckBox_Infinite Robot Skill 2"),
            OBFUSCATE("CheckBox_No Duration Robot Skill 2"),
            OBFUSCATE("CheckBox_Infinite Module"),
            OBFUSCATE("CheckBox_Instant Titan Charge"),
            OBFUSCATE("CheckBox_Fast Energy Refresh"),
            OBFUSCATE("CheckBox_Auto Ability 1"),
            OBFUSCATE("CheckBox_Auto Ability 2"),
            OBFUSCATE("CheckBox_Auto Ability 1 and 2"),

            // ── WEAPONS ───────────────────────────────────────────────
            OBFUSCATE("Category_WEAPONS"),
            OBFUSCATE("CheckBox_Rapid Fire"),
            OBFUSCATE("CheckBox_Auto Fire No Delay"),
            OBFUSCATE("CheckBox_Weapon Range 1100m"),
            OBFUSCATE("CheckBox_No Reload"),
            OBFUSCATE("CheckBox_No Recoil"),
            OBFUSCATE("CheckBox_Infinite Ammo"),
            OBFUSCATE("CheckBox_Damage Multiplier"),
            OBFUSCATE("CheckBox_Big Radius Damage"),
            OBFUSCATE("CheckBox_Instant Charge Weapons"),
            OBFUSCATE("CheckBox_Perfect Accuracy"),
            OBFUSCATE("CheckBox_Instant Hit Projectile"),
            OBFUSCATE("CheckBox_Max Turret Rotation"),

            // ── DEFENSE ───────────────────────────────────────────────
            OBFUSCATE("Category_DEFENSE"),
            OBFUSCATE("CheckBox_God Mode"),
            OBFUSCATE("CheckBox_Infinite HP"),
            OBFUSCATE("CheckBox_Max HP Boost"),
            OBFUSCATE("CheckBox_Anti Death"),
            OBFUSCATE("CheckBox_Infinite Energy Shield"),
            OBFUSCATE("CheckBox_Anti EMP Block"),
            OBFUSCATE("CheckBox_Anti Skill Block"),
            OBFUSCATE("CheckBox_Anti Lockdown"),
            OBFUSCATE("CheckBox_Anti Blind"),

            // ── TARGETING ─────────────────────────────────────────────
            OBFUSCATE("Category_TARGETING"),
            OBFUSCATE("CheckBox_Instant Target Lock"),
            OBFUSCATE("CheckBox_See Through Stealth"),
            OBFUSCATE("CheckBox_Wide FOV"),

            // ── TELEPORT ──────────────────────────────────────────────
            OBFUSCATE("Category_TELEPORT"),
            OBFUSCATE("CheckBox_Teleport to Beacon"),
            OBFUSCATE("CheckBox_Underground Mode"),

            // ── MATCH ─────────────────────────────────────────────────
            OBFUSCATE("Category_MATCH"),
            OBFUSCATE("CheckBox_Fast Match End"),

            // ── BOTS ──────────────────────────────────────────────────
            OBFUSCATE("Category_BOTS / MAP"),
            OBFUSCATE("CheckBox_Disable Bot AI"),
            OBFUSCATE("CheckBox_Short Distance"),

            // ── MISC ──────────────────────────────────────────────────
            OBFUSCATE("Category_MISC"),
            OBFUSCATE("CheckBox_Instant Box"),
            OBFUSCATE("CheckBox_No Ads Skip Popup"),
            OBFUSCATE("CheckBox_Instant Upgrade"),
        };

        //Now you dont have to manually update the number everytime;
        int Total_Feature = (sizeof features / sizeof features[0]);
        ret = (jobjectArray)
        env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
            env->NewStringUTF(""));

        for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

        pthread_t ptid;
        pthread_create(&ptid, NULL, antiLeech, NULL);

        return (ret);
    }

    JNIEXPORT void JNICALL
    Java_uk_lgl_modmenu_Preferences_Changes(JNIEnv *env, jclass clazz, jobject obj,
        jint featNum, jstring featName, jint value,
        jboolean boolean, jstring str) {

        LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
            env->GetStringUTFChars(featName, 0), value,
            boolean, str != NULL ? env->GetStringUTFChars(str, 0): "");

        //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

        switch (featNum) {
            // ── MOVEMENT ──────────────────────────────────────────────
            case 0:  Send(f::f1, boolean); break; // SpeedHack
            case 1:  Send(f::f2, boolean); break; // Disable Gravity
            case 2:  Send(f::f3, boolean); break; // Noclip
            case 3:  Send(f::f4, boolean); break; // Multiple Jump
            case 4:  Send(f::f5, boolean); break; // No Jump
            case 5:  Send(f::f6, boolean); break; // Super Jump
            // ── ABILITIES ─────────────────────────────────────────────
            case 6:  Send(f::f7, boolean); break; // Infinite Skill 1
            case 7:  Send(f::f8, boolean); break; // No Duration Skill 1
            case 8:  Send(f::f9, boolean); break; // Infinite Skill 2
            case 9:  Send(f::f10, boolean); break; // No Duration Skill 2
            case 10: Send(f::f1 + 10, boolean); break; // Infinite Module
            case 11: Send(f::f1 + 11, boolean); break; // Titan Charge
            case 12: Send(f::f1 + 12, boolean); break; // Energy Refresh
            case 13: Send(f::f1 + 13, boolean); break; // Auto Ability 1
            case 14: Send(f::f1 + 14, boolean); break; // Auto Ability 2
            case 15: Send(f::f1 + 15, boolean); break; // Auto Ability Both
            // ── WEAPONS ───────────────────────────────────────────────
            case 16: Send(f::f1 + 16, boolean); break; // Rapid Fire
            case 17: Send(f::f1 + 17, boolean); break; // Auto Fire
            case 18: Send(f::f1 + 18, boolean); break; // Weapon Range
            case 19: Send(f::f1 + 19, boolean); break; // No Reload
            case 20: Send(f::f1 + 20, boolean); break; // No Recoil
            case 21: Send(f::f1 + 21, boolean); break; // Infinite Ammo
            case 22: Send(f::f1 + 22, boolean); break; // Damage Mult
            case 23: Send(f::f1 + 23, boolean); break; // Big Radius
            case 24: Send(f::f1 + 24, boolean); break; // Charge Rate
            case 25: Send(f::f1 + 25, boolean); break; // Perfect Accuracy
            case 26: Send(f::f1 + 26, boolean); break; // Projectile Speed
            case 27: Send(f::f1 + 27, boolean); break; // Turret Speed
            // ── DEFENSE ───────────────────────────────────────────────
            case 28: Send(f::f1 + 28, boolean); break; // God Mode
            case 29: Send(f::f1 + 29, boolean); break; // Infinite HP
            case 30: Send(f::f1 + 30, boolean); break; // Max HP
            case 31: Send(f::f1 + 31, boolean); break; // Anti Death
            case 32: Send(f::f1 + 32, boolean); break; // Infinite Shield
            case 33: Send(f::f1 + 33, boolean); break; // Anti EMP
            case 34: Send(f::f1 + 34, boolean); break; // Anti Skill
            case 35: Send(f::f1 + 35, boolean); break; // Anti Lockdown
            case 36: Send(f::f1 + 36, boolean); break; // Anti Blind
            // ── TARGETING ─────────────────────────────────────────────
            case 37: Send(f::f1 + 37, boolean); break; // Target Lock
            case 38: Send(f::f1 + 38, boolean); break; // Anti Stealth
            case 39: Send(f::f1 + 39, boolean); break; // Wide FOV
            // ── TELEPORT ──────────────────────────────────────────────
            case 40: Send(f::f1 + 40, boolean); break; // Teleport Beacon
            case 41: Send(f::f1 + 41, boolean); break; // Underground
            // ── MATCH ─────────────────────────────────────────────────
            case 42: Send(f::f1 + 42, boolean); break; // Fast Match End
            // ── BOTS ──────────────────────────────────────────────────
            case 43: Send(f::f1 + 43, boolean); break; // Bots Dont Shoot
            case 44: Send(f::f1 + 44, boolean); break; // Short Distance
            // ── MISC ──────────────────────────────────────────────────
            case 45: Send(f::f1 + 45, boolean); break; // Instant Box
            case 46: Send(f::f1 + 46, boolean); break; // No Ads
            case 47: Send(f::f1 + 47, boolean); break; // Instant Upgrade
            default: break;
        }
    }
}
void DrawESP(ESP esp, int screenWidth, int screenHeight) {
    // No overlay watermark
}


extern "C"
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_DrawOn(JNIEnv *env, jclass type, jobject espView, jobject canvas) {
    espOverlay = ESP(env, espView, canvas);
    if (espOverlay.isValid()) {
        DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
    }
}

extern "C" {
    JNIEXPORT jboolean JNICALL
    Java_uk_lgl_modmenu_FloatingModMenuService_IsConnected(JNIEnv *env, jobject thiz) {
        return client.connected;
    }
}


extern "C"
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Init(JNIEnv *env, jobject thiz) {
    startClient();
}

extern "C"
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Stop(JNIEnv *env, jobject type) {
    stopClient();
}
