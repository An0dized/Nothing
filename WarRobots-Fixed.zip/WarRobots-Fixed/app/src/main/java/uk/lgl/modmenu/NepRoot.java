package uk.lgl.modmenu;

import android.app.AlertDialog;
import com.topjohnwu.superuser.Shell;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import uk.lgl.MainActivity;

public class NepRoot {

    private MainActivity thiz;

    public NepRoot(MainActivity thiz) {
        this.thiz = thiz;
    }

    public void showNoRootMessage() {
        (new AlertDialog.Builder(thiz))
			.setMessage("Could not acquire root")
			.setNegativeButton(android.R.string.ok, null)
			.show();
    }

    public int Game(String pkg) {
        try {
            List<String> arrayList = new ArrayList<>();
            Shell.Result result = Shell.su("(toolbox ps; toolbox ps -A; toybox ps; toybox ps -A) | grep \" " + pkg + "$\"").exec();
            arrayList = result.getOut();
            Iterator<String> iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                String Trim = iterator.next().trim();
                while (Trim.contains("  ")) {
                    Trim = Trim.replace("  ", " ");
                }
                String[] Split = Trim.split(" ");
                if (Split.length >= 2) {
                    return Integer.parseInt(Split[1]);
                }
            }
            return -1;
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }
}
