//Please don't replace listeners with lambda!

package uk.lgl.modmenu;

import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlertDialog;
import android.app.Service;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import com.topjohnwu.superuser.Shell;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_LEFT;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.content.Context;
import java.util.ArrayList;
import java.io.File;
import java.util.Iterator;
import java.util.Locale;
import com.topjohnwu.superuser.internal.Utils;

public class FloatingModMenuService extends Service {
    //********** Here you can easly change the menu appearance **********//

    //***************** TARGET *********//
    String LibName = "libLibServer.so";
    String targetPackage = "com.pixonic.wwr";


    //region Variable
    public static final String TAG = "Mod_Menu"; //Tag for logcat
    int TEXT_COLOR = Color.parseColor("#E0E0E0");
    int TEXT_COLOR_2 = Color.parseColor("#FFFFFF");
    int BTN_COLOR = Color.parseColor("#1A1A2E");
    int MENU_BG_COLOR = Color.parseColor("#F0101020"); //#AARRGGBB
    int MENU_FEATURE_BG_COLOR = Color.parseColor("#E0080818"); //#AARRGGBB
    int MENU_WIDTH = 290;
    int MENU_HEIGHT = 210;
    float MENU_CORNER = 4f;
    int ICON_SIZE = 45; //Change both width and height of image
    float ICON_ALPHA = 0.7f; //Transparent
    int ToggleON = Color.parseColor("#7C4DFF");
    int ToggleOFF = Color.RED;
    int BtnON = Color.parseColor("#3700B3");
    int BtnOFF = Color.parseColor("#1A1A2E");
    int CategoryBG = Color.parseColor("#1A1A3A");
    int SeekBarColor = Color.parseColor("#7C4DFF");
    int SeekBarProgressColor = Color.parseColor("#7C4DFF");
    int CheckBoxColor = Color.parseColor("#7C4DFF");
    int RadioColor = Color.parseColor("#FFFFFF");
    String NumberTxtColor = "#7C4DFF";
    //********************************************************************//
    RelativeLayout mCollapsed, mRootContainer;
    LinearLayout mExpanded, patches, mSettings, mCollapse;
    LinearLayout.LayoutParams scrlLLExpanded, scrlLL;
    private WindowManager.LayoutParams espParams;
    private NepEsp overlayView;
    WindowManager mWindowManager;
    WindowManager.LayoutParams params;
    ImageView startimage;
    FrameLayout rootFrame;
    ScrollView scrollView;

    boolean stopChecking;

    //initialize methods from the native library
    native void setTitleText(TextView textView);

    native void setHeadingText(TextView textView);

    native String Icon();

    native String IconWebViewData();

    native String[] getFeatureList();

    native String[] settingsList();

    native boolean isGameLibLoaded();

    static native void DrawOn(NepEsp espView, Canvas canvas);

    native boolean IsConnected();

    native void Init();

    native void Stop();
    //endregion

    //When this Class is called the code in this function will be executed
    @Override
    public void onCreate() {
        super.onCreate();
        Preferences.context = this;
        this.overlayView = new NepEsp((Context) this);
        //Create the menu
        initFloating();
        DrawCanvas();
        //Create a handler for this Class
        final Handler handler = new Handler();
        handler.post(new Runnable() {
				public void run() {

					Thread();
					handler.postDelayed(this, 1000);
				}
			});
    }

    private int getLayoutType() {
        int LAYOUT_FLAG;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_TOAST;
        } else {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        }
        return LAYOUT_FLAG;
    }
    private void DrawCanvas() {


        WindowManager.LayoutParams layoutParams;
        this.espParams = layoutParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.MATCH_PARENT,
			WindowManager.LayoutParams.MATCH_PARENT,
			this.getLayoutType(),
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
			WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
			PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        this.espParams.x = 0;
        this.espParams.y = 100;
        this.mWindowManager.addView((View) this.overlayView, (ViewGroup.LayoutParams) this.espParams);
    }


    //Here we write the code for our Menu
    // Reference: https://www.androidhive.info/2016/11/android-floating-widget-like-facebook-chat-head/
    private void initFloating() {
        rootFrame = new FrameLayout(this); // Global markup
        rootFrame.setOnTouchListener(onTouchListener());
        mRootContainer = new RelativeLayout(this); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(this); // Markup of the icon (when the menu is minimized)
        mCollapsed.setVisibility(View.VISIBLE);
        mCollapsed.setAlpha(ICON_ALPHA);

        //********** The box of the mod menu **********
        mExpanded = new LinearLayout(this); // Menu markup (when the menu is expanded)
        mExpanded.setVisibility(View.GONE);
        mExpanded.setBackgroundColor(MENU_BG_COLOR);
        mExpanded.setOrientation(LinearLayout.VERTICAL);
        // mExpanded.setPadding(1, 1, 1, 1); //So borders would be visible
        mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(MENU_WIDTH), WRAP_CONTENT));
        GradientDrawable gdMenuBody = new GradientDrawable();
        gdMenuBody.setCornerRadius(MENU_CORNER); //Set corner
        gdMenuBody.setColor(MENU_BG_COLOR); //Set background color
        gdMenuBody.setStroke(1, Color.parseColor("#7C4DFF")); //Set border
        //mExpanded.setBackground(gdMenuBody); //Apply GradientDrawable to it

        //********** The icon to open mod menu **********
        startimage = new ImageView(this);
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
        int applyDimension = (int) TypedValue.applyDimension(1, ICON_SIZE, getResources().getDisplayMetrics()); //Icon size
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        //startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode(Icon(), 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);
        //Initialize event handlers for buttons, etc.
        startimage.setOnTouchListener(onTouchListener());
        startimage.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					mCollapsed.setVisibility(View.GONE);
					mExpanded.setVisibility(View.VISIBLE);
				}
			});

        //********** The icon in Webview to open mod menu **********
        WebView wView = new WebView(this); //Icon size width=\"50\" height=\"50\"
        wView.setLayoutParams(new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
        int applyDimension2 = (int) TypedValue.applyDimension(1, ICON_SIZE, getResources().getDisplayMetrics()); //Icon size
        wView.getLayoutParams().height = applyDimension2;
        wView.getLayoutParams().width = applyDimension2;
        wView.loadData("<html>" +
					   "<head></head>" +
					   "<body style=\"margin: 0; padding: 0\">" +
					   "<img src=\"" + IconWebViewData() + "\" width=\"" + ICON_SIZE + "\" height=\"" + ICON_SIZE + "\" >" +
					   "</body>" +
					   "</html>", "text/html", "utf-8");
        wView.setBackgroundColor(0x00000000); //Transparent
        wView.setAlpha(ICON_ALPHA);
        wView.getSettings().setAppCacheEnabled(true);
        wView.setOnTouchListener(onTouchListener());

        //********** Settings icon **********
        TextView settings = new TextView(this); //Android 5 can't show ⚙, instead show other icon instead
        settings.setText(Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M ? "⚙" : "\uD83D\uDD27");
        settings.setTextColor(TEXT_COLOR);
        settings.setTypeface(Typeface.DEFAULT_BOLD);
        settings.setTextSize(20.0f);
        RelativeLayout.LayoutParams rlsettings = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rlsettings.addRule(ALIGN_PARENT_RIGHT);
        settings.setLayoutParams(rlsettings);
        settings.setOnClickListener(new View.OnClickListener() {
				boolean settingsOpen;

				@Override
				public void onClick(View v) {
					try {
						settingsOpen = !settingsOpen;
						if (settingsOpen) {
							scrollView.removeView(patches);
							scrollView.addView(mSettings);
							scrollView.scrollTo(0, 0);
						} else {
							scrollView.removeView(mSettings);
							scrollView.addView(patches);
						}
					} catch (IllegalStateException e) {
					}
				}
			});

        //********** Settings **********
        mSettings = new LinearLayout(this);
        mSettings.setOrientation(LinearLayout.VERTICAL);
        featureList(settingsList(), mSettings);

        //********** Title text **********
        RelativeLayout titleText = new RelativeLayout(this);
        titleText.setPadding(10, 5, 10, 5);
        titleText.setVerticalGravity(16);

        TextView title = new TextView(this);
        title.setTextColor(TEXT_COLOR);
        title.setTextSize(18.0f);
        title.setGravity(Gravity.CENTER);
        RelativeLayout.LayoutParams rl = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rl.addRule(RelativeLayout.CENTER_HORIZONTAL);
        title.setLayoutParams(rl);
        setTitleText(title);

        //********** Heading text **********
        TextView heading = new TextView(this);
        //heading.setText(Html.fromHtml(Heading()));
        heading.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        heading.setMarqueeRepeatLimit(-1);
        heading.setSingleLine(true);
        heading.setSelected(true);
        heading.setTextColor(TEXT_COLOR);
        heading.setTextSize(10.0f);
        heading.setGravity(Gravity.CENTER);
        heading.setPadding(0, 0, 0, 5);
        setHeadingText(heading);

        //********** Mod menu feature list **********
        scrollView = new ScrollView(this);
        //Auto size. To set size manually, change the width and height example 500, 500
        scrlLL = new LinearLayout.LayoutParams(MATCH_PARENT, dp(MENU_HEIGHT));
        scrlLLExpanded = new LinearLayout.LayoutParams(mExpanded.getLayoutParams());
        scrlLLExpanded.weight = 1.0f;
        scrollView.setLayoutParams(Preferences.isExpanded ? scrlLLExpanded : scrlLL);
        scrollView.setBackgroundColor(MENU_FEATURE_BG_COLOR);
        patches = new LinearLayout(this);
        patches.setOrientation(LinearLayout.VERTICAL);

        //********** RelativeLayout for buttons **********
        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setPadding(10, 3, 10, 3);
        relativeLayout.setVerticalGravity(Gravity.CENTER);

        //**********  Hide/Kill button **********
        RelativeLayout.LayoutParams lParamsHideBtn = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        lParamsHideBtn.addRule(ALIGN_PARENT_LEFT);

        Button hideBtn = new Button(this);
        hideBtn.setLayoutParams(lParamsHideBtn);
        hideBtn.setBackgroundColor(Color.TRANSPARENT);
        hideBtn.setText("HIDE/KILL (Hold)");
        hideBtn.setTextColor(TEXT_COLOR);
        hideBtn.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					mCollapsed.setVisibility(View.VISIBLE);
					mCollapsed.setAlpha(0);
					mExpanded.setVisibility(View.GONE);
					Toast.makeText(view.getContext(), "Icon hidden. Remember the hidden icon position", Toast.LENGTH_LONG).show();
				}
			});
        hideBtn.setOnLongClickListener(new View.OnLongClickListener() {
				public boolean onLongClick(View view) {
					Toast.makeText(view.getContext(), "Menu service killed", Toast.LENGTH_LONG).show();
					FloatingModMenuService.this.stopSelf();
					return false;
				}
			});

        //********** Close button **********
        RelativeLayout.LayoutParams lParamsCloseBtn = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        lParamsCloseBtn.addRule(ALIGN_PARENT_RIGHT);

        Button closeBtn = new Button(this);
        closeBtn.setLayoutParams(lParamsCloseBtn);
        closeBtn.setBackgroundColor(Color.TRANSPARENT);
        closeBtn.setText("MINIMIZE");
        closeBtn.setTextColor(TEXT_COLOR);
        closeBtn.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					mCollapsed.setVisibility(View.VISIBLE);
					mCollapsed.setAlpha(ICON_ALPHA);
					mExpanded.setVisibility(View.GONE);
				}
			});

        //********** Params **********
        //Variable to check later if the phone supports Draw over other apps permission
        int iparams = Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O ? 2038 : 2002;
        params = new WindowManager.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, iparams,
												WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
												WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, -3);
        params.gravity = 51;
        params.x = 0;
        params.y = 100;

        //********** Adding view components **********
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);
        if (IconWebViewData() != null) {
            mCollapsed.addView(wView);
        } else {
            mCollapsed.addView(startimage);
        }
        titleText.addView(title);
        titleText.addView(settings);
        mExpanded.addView(titleText);
        mExpanded.addView(heading);
        scrollView.addView(patches);
        mExpanded.addView(scrollView);
        relativeLayout.addView(hideBtn);
        relativeLayout.addView(closeBtn);
        mExpanded.addView(relativeLayout);
        mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mWindowManager.addView(rootFrame, params);

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
				boolean viewLoaded = false;

				@Override
				public void run() {
					//If the save preferences is enabled, it will check if game lib is loaded before starting menu
					//Comment the if-else code out except startService if you want to run the app and test preferences
					if (Preferences.loadPref && !isGameLibLoaded() && !stopChecking) {
						if (!viewLoaded) {
							patches.addView(Category("Save preferences was been enabled. Waiting for game lib to be loaded...\n\nForce load menu may not apply mods instantly. You would need to reactivate them again"));
							patches.addView(Button(-100, "Force load menu"));
							viewLoaded = true;
						}
						handler.postDelayed(this, 600);
					} else {
						patches.removeAllViews();
						InjectBtn(patches);
						//  featureList(getFeatureList(), patches);
					}
				}
			}, 500);
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX, initialTouchY;
            private int initialX, initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);
                        mExpanded.setAlpha(1f);
                        mCollapsed.setAlpha(1f);
                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            //When user clicks on the image view of the collapsed layout,
                            //visibility of the collapsed layout will be changed to "View.GONE"
                            //and expanded view will become visible.
                            try {
                                collapsedView.setVisibility(View.GONE);
                                expandedView.setVisibility(View.VISIBLE);
                            } catch (NullPointerException e) {

                            }
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        mExpanded.setAlpha(0.5f);
                        mCollapsed.setAlpha(0.5f);
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));
                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(rootFrame, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    private void featureList(String[] listFT, LinearLayout linearLayout) {
        //Currently looks messy right now. Let me know if you have improvements
        linearLayout.removeAllViews();
        int featNum, subFeat = 0;
        LinearLayout llBak = linearLayout;

        for (int i = 0; i < listFT.length; i++) {
            boolean switchedOn = false;
            //Log.i("featureList", listFT[i]);
            String feature = listFT[i];
            if (feature.contains("True_")) {
                switchedOn = true;
                feature = feature.replaceFirst("True_", "");
            }

            linearLayout = llBak;
            if (feature.contains("CollapseAdd_")) {
                //if (collapse != null)
                linearLayout = mCollapse;
                feature = feature.replaceFirst("CollapseAdd_", "");
            }
            String[] str = feature.split("_");

            //Assign feature number
            if (TextUtils.isDigitsOnly(str[0]) || str[0].matches("-[0-9]*")) {
                featNum = Integer.parseInt(str[0]);
                feature = feature.replaceFirst(str[0] + "_", "");
                subFeat++;
            } else {
                //Subtract feature number. We don't want to count ButtonLink, Category, RichTextView and RichWebView
                featNum = i - subFeat;
            }
            String[] strSplit = feature.split("_");
            switch (strSplit[0]) {
                case "Toggle":
                    linearLayout.addView(Switch(featNum, strSplit[1], switchedOn));
                    break;
                case "SeekBar":
                    linearLayout.addView(SeekBar(featNum, strSplit[1], Integer.parseInt(strSplit[2]), Integer.parseInt(strSplit[3])));
                    break;
                case "Button":
                    linearLayout.addView(Button(featNum, strSplit[1]));
                    break;
                case "ButtonOnOff":
                    linearLayout.addView(ButtonOnOff(featNum, strSplit[1], switchedOn));
                    break;
                case "Spinner":
                    linearLayout.addView(RichTextView(strSplit[1]));
                    linearLayout.addView(Spinner(featNum, strSplit[1], strSplit[2]));
                    break;
                case "InputText":
                    linearLayout.addView(TextField(featNum, strSplit[1], false, 0));
                    break;
                case "InputValue":
                    if (strSplit.length == 3)
                        linearLayout.addView(TextField(featNum, strSplit[2], true, Integer.parseInt(strSplit[1])));
                    if (strSplit.length == 2)
                        linearLayout.addView(TextField(featNum, strSplit[1], true, 0));
                    break;
                case "CheckBox":
                    linearLayout.addView(CheckBox(featNum, strSplit[1], switchedOn));
                    break;
                case "RadioButton":
                    linearLayout.addView(RadioButton(featNum, strSplit[1], strSplit[2]));
                    break;
                case "Collapse":
                    Collapse(linearLayout, strSplit[1]);
                    subFeat++;
                    break;
                case "ButtonLink":
                    subFeat++;
                    linearLayout.addView(ButtonLink(strSplit[1], strSplit[2]));
                    break;
                case "Category":
                    subFeat++;
                    linearLayout.addView(Category(strSplit[1]));
                    break;
                case "RichTextView":
                    subFeat++;
                    linearLayout.addView(RichTextView(strSplit[1]));
                    break;
                case "RichWebView":
                    subFeat++;
                    linearLayout.addView(RichWebView(strSplit[1]));
                    break;
            }
        }
    }

    private View Switch(final int featNum, final String featName, boolean swiOn) {
        final Switch switchR = new Switch(this);
        ColorStateList buttonStates = new ColorStateList(
			new int[][]{
				new int[]{-android.R.attr.state_enabled},
				new int[]{android.R.attr.state_checked},
				new int[]{}
			},
			new int[]{
				Color.BLUE,
				ToggleON, // ON
				ToggleOFF // OFF
			}
        );
        //Set colors of the switch. Comment out if you don't like it
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            switchR.getThumbDrawable().setTintList(buttonStates);
            switchR.getTrackDrawable().setTintList(buttonStates);
        }
        switchR.setText(featName);
        switchR.setTextColor(TEXT_COLOR_2);
        switchR.setPadding(10, 5, 0, 5);
        switchR.setChecked(Preferences.loadPrefBool(featName, featNum, swiOn));
        switchR.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton compoundButton, boolean bool) {
					Preferences.changeFeatureBool(featName, featNum, bool);
					switch (featNum) {
						case -1: //Save perferences
							Preferences.with(switchR.getContext()).writeBoolean(-1, bool);
							if (bool == false)
								Preferences.with(switchR.getContext()).clear(); //Clear perferences if switched off
							break;
						case -3:
							Preferences.isExpanded = bool;
							scrollView.setLayoutParams(bool ? scrlLLExpanded : scrlLL);
							break;
					}
				}
			});
        return switchR;
    }

    private View SeekBar(final int featNum, final String featName, final int min, int max) {
        int loadedProg = Preferences.loadPrefInt(featName, featNum);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER);

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml(featName + ": <font color='" + NumberTxtColor + "'>" + ((loadedProg == 0) ? min : loadedProg)));
        textView.setTextColor(TEXT_COLOR_2);

        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setMax(max);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            seekBar.setMin(min); //setMin for Oreo and above
        seekBar.setProgress((loadedProg == 0) ? min : loadedProg);
        seekBar.getThumb().setColorFilter(SeekBarColor, PorterDuff.Mode.SRC_ATOP);
        seekBar.getProgressDrawable().setColorFilter(SeekBarProgressColor, PorterDuff.Mode.SRC_ATOP);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
				}

				public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
					//if progress is greater than minimum, don't go below. Else, set progress
					seekBar.setProgress(i < min ? min : i);
					Preferences.changeFeatureInt(featName, featNum, i < min ? min : i);
					textView.setText(Html.fromHtml(featName + ": <font color='" + NumberTxtColor + "'>" + (i < min ? min : i)));
				}
			});
        linearLayout.addView(textView);
        linearLayout.addView(seekBar);

        return linearLayout;
    }

    private View Button(final int featNum, final String featName) {
        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParams.setMargins(7, 5, 7, 5);
        button.setLayoutParams(layoutParams);
        button.setTextColor(TEXT_COLOR_2);
        button.setAllCaps(false); //Disable caps to support html
        button.setText(Html.fromHtml(featName));
        button.setBackgroundColor(BTN_COLOR);
        button.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					switch (featNum) {
						case -4:
							Logcat.Save(getApplicationContext());
							break;
						case -5:
							Logcat.Clear(getApplicationContext());
							break;
						case -6:
							scrollView.removeView(mSettings);
							scrollView.addView(patches);
							break;
						case -100:
							stopChecking = true;
							break;
					}
					Preferences.changeFeatureInt(featName, featNum, 0);
				}
			});

        return button;
    }

    private View ButtonLink(final String featName, final String url) {
        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParams.setMargins(7, 5, 7, 5);
        button.setLayoutParams(layoutParams);
        button.setAllCaps(false); //Disable caps to support html
        button.setTextColor(TEXT_COLOR_2);
        button.setText(Html.fromHtml(featName));
        button.setBackgroundColor(BTN_COLOR);
        button.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					Intent intent = new Intent(Intent.ACTION_VIEW);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					intent.setData(Uri.parse(url));
					startActivity(intent);
				}
			});
        return button;
    }

    private View ButtonOnOff(final int featNum, String featName, boolean switchedOn) {
        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParams.setMargins(7, 5, 7, 5);
        button.setLayoutParams(layoutParams);
        button.setTextColor(TEXT_COLOR_2);
        button.setAllCaps(false); //Disable caps to support html

        final String finalfeatName = featName.replace("OnOff_", "");
        boolean isOn = Preferences.loadPrefBool(featName, featNum, switchedOn);
        if (isOn) {
            button.setText(Html.fromHtml(finalfeatName + ": ON"));
            button.setBackgroundColor(BtnON);
            isOn = false;
        } else {
            button.setText(Html.fromHtml(finalfeatName + ": OFF"));
            button.setBackgroundColor(BtnOFF);
            isOn = true;
        }
        final boolean finalIsOn = isOn;
        button.setOnClickListener(new View.OnClickListener() {
				boolean isOn = finalIsOn;

				public void onClick(View v) {
					Preferences.changeFeatureBool(finalfeatName, featNum, isOn);
					//Log.d(TAG, finalfeatName + " " + featNum + " " + isActive2);
					if (isOn) {
						button.setText(Html.fromHtml(finalfeatName + ": ON"));
						button.setBackgroundColor(BtnON);
						isOn = false;
					} else {
						button.setText(Html.fromHtml(finalfeatName + ": OFF"));
						button.setBackgroundColor(BtnOFF);
						isOn = true;
					}
				}
			});
        return button;
    }

    private View Spinner(final int featNum, final String featName, final String list) {
        Log.d(TAG, "spinner " + featNum + " " + featName + " " + list);
        final List<String> lists = new LinkedList<>(Arrays.asList(list.split(",")));

        // Create another LinearLayout as a workaround to use it as a background
        // to keep the down arrow symbol. No arrow symbol if setBackgroundColor set
        LinearLayout linearLayout2 = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT);
        layoutParams2.setMargins(7, 2, 7, 5);
        linearLayout2.setOrientation(LinearLayout.VERTICAL);
        linearLayout2.setBackgroundColor(BTN_COLOR);
        linearLayout2.setLayoutParams(layoutParams2);

        final Spinner spinner = new Spinner(this, Spinner.MODE_DROPDOWN);
        spinner.setLayoutParams(layoutParams2);
        spinner.getBackground().setColorFilter(1, PorterDuff.Mode.SRC_ATOP); //trick to show white down arrow color
        //Creating the ArrayAdapter instance having the list
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, lists);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner'
        spinner.setAdapter(aa);
        spinner.setSelection(Preferences.loadPrefInt(featName, featNum));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
				@Override
				public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
					Preferences.changeFeatureInt(spinner.getSelectedItem().toString(), featNum, position);
					((TextView) parentView.getChildAt(0)).setTextColor(TEXT_COLOR_2);
				}

				@Override
				public void onNothingSelected(AdapterView<?> parent) {
				}
			});
        linearLayout2.addView(spinner);
        return linearLayout2;
    }

    private View TextField(final int featNum, final String featName, final boolean numOnly, final int maxValue) {
        final EditTextString edittextstring = new EditTextString();
        final EditTextNum edittextnum = new EditTextNum();
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParams.setMargins(7, 5, 7, 5);

        final Button button = new Button(this);
        if (numOnly) {
            int num = Preferences.loadPrefInt(featName, featNum);
            edittextnum.setNum((num == 0) ? 1 : num);
            button.setText(Html.fromHtml(featName + ": <font color='" + NumberTxtColor + "'>" + ((num == 0) ? 1 : num) + "</font>"));
        } else {
            String string = Preferences.loadPrefString(featName, featNum);
            edittextstring.setString((string == "") ? "" : string);
            button.setText(Html.fromHtml(featName + ": <font color='" + NumberTxtColor + "'>" + string + "</font>"));
        }
        button.setAllCaps(false);
        button.setLayoutParams(layoutParams);
        button.setBackgroundColor(BTN_COLOR);
        button.setTextColor(TEXT_COLOR_2);
        button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					final AlertDialog alert = new AlertDialog.Builder(getApplicationContext(), 2).create();
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
						Objects.requireNonNull(alert.getWindow()).setType(Build.VERSION.SDK_INT >= 26 ? 2038 : 2002);
					}
					alert.setOnCancelListener(new DialogInterface.OnCancelListener() {
							public void onCancel(DialogInterface dialog) {
								InputMethodManager imm = (InputMethodManager) getSystemService(getApplicationContext().INPUT_METHOD_SERVICE);
								imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
							}
						});

					//LinearLayout
					LinearLayout linearLayout1 = new LinearLayout(getApplicationContext());
					linearLayout1.setPadding(5, 5, 5, 5);
					linearLayout1.setOrientation(LinearLayout.VERTICAL);
					linearLayout1.setBackgroundColor(MENU_FEATURE_BG_COLOR);

					//TextView
					final TextView TextViewNote = new TextView(getApplicationContext());
					TextViewNote.setText("Tap OK to apply changes. Tap outside to cancel");
					if (maxValue != 0)
						TextViewNote.setText("Tap OK to apply changes. Tap outside to cancel\nMax value: " + maxValue);
					TextViewNote.setTextColor(TEXT_COLOR_2);

					//Edit text
					final EditText edittext = new EditText(getApplicationContext());
					edittext.setMaxLines(1);
					edittext.setWidth(convertDipToPixels(300));
					edittext.setTextColor(TEXT_COLOR_2);
					if (numOnly) {
						edittext.setInputType(InputType.TYPE_CLASS_NUMBER);
						edittext.setKeyListener(DigitsKeyListener.getInstance("0123456789-"));
						InputFilter[] FilterArray = new InputFilter[1];
						FilterArray[0] = new InputFilter.LengthFilter(10);
						edittext.setFilters(FilterArray);
					} else {
						edittext.setText(edittextstring.getString());
					}
					edittext.setOnFocusChangeListener(new View.OnFocusChangeListener() {
							@Override
							public void onFocusChange(View v, boolean hasFocus) {
								InputMethodManager imm = (InputMethodManager) getSystemService(getApplicationContext().INPUT_METHOD_SERVICE);
								if (hasFocus) {
									imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
								} else {
									imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
								}
							}
						});
					edittext.requestFocus();

					//Button
					Button btndialog = new Button(getApplicationContext());
					btndialog.setBackgroundColor(BTN_COLOR);
					btndialog.setTextColor(TEXT_COLOR_2);
					btndialog.setText("OK");
					btndialog.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View view) {
								if (numOnly) {
									int num;
									try {
										num = Integer.parseInt(TextUtils.isEmpty(edittext.getText().toString()) ? "0" : edittext.getText().toString());
										if (maxValue != 0 &&  num >= maxValue)
											num = maxValue;
									} catch (NumberFormatException ex) {
										num = 2147483640;
									}
									edittextnum.setNum(num);
									button.setText(Html.fromHtml(featName + ": <font color='" + NumberTxtColor + "'>" + num + "</font>"));
									alert.dismiss();
									Preferences.changeFeatureInt(featName, featNum, num);
								} else {
									String str = edittext.getText().toString();
									edittextstring.setString(edittext.getText().toString());
									button.setText(Html.fromHtml(featName + ": <font color='" + NumberTxtColor + "'>" + str + "</font>"));
									alert.dismiss();
									Preferences.changeFeatureString(featName, featNum, str);
								}
								edittext.setFocusable(false);
							}
						});

					linearLayout1.addView(TextViewNote);
					linearLayout1.addView(edittext);
					linearLayout1.addView(btndialog);
					alert.setView(linearLayout1);
					alert.show();
				}
			});

        linearLayout.addView(button);
        return linearLayout;
    }

    private View CheckBox(final int featNum, final String featName, boolean switchedOn) {
        final CheckBox checkBox = new CheckBox(this);
        checkBox.setText(featName);
        checkBox.setTextColor(TEXT_COLOR_2);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            checkBox.setButtonTintList(ColorStateList.valueOf(CheckBoxColor));
        checkBox.setChecked(Preferences.loadPrefBool(featName, featNum, switchedOn));
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if (checkBox.isChecked()) {
						Preferences.changeFeatureBool(featName, featNum, isChecked);
					} else {
						Preferences.changeFeatureBool(featName, featNum, isChecked);
					}
				}
			});
        return checkBox;
    }

    private View RadioButton(final int featNum, String featName, final String list) {
        //Credit: LoraZalora
        final List<String> lists = new LinkedList<>(Arrays.asList(list.split(",")));

        final TextView textView = new TextView(this);
        textView.setText(featName + ":");
        textView.setTextColor(TEXT_COLOR_2);

        final RadioGroup radioGroup = new RadioGroup(this);
        radioGroup.setPadding(10, 5, 10, 5);
        radioGroup.setOrientation(LinearLayout.VERTICAL);
        radioGroup.addView(textView);

        for (int i = 0; i < lists.size(); i++) {
            final RadioButton Radioo = new RadioButton(this);
            final String finalfeatName = featName, radioName = lists.get(i);
            View.OnClickListener first_radio_listener = new View.OnClickListener() {
                public void onClick(View v) {
                    textView.setText(Html.fromHtml(finalfeatName + ": <font color='" + NumberTxtColor + "'>" + radioName));
                    Preferences.changeFeatureInt(finalfeatName, featNum, radioGroup.indexOfChild(Radioo));
                }
            };
            System.out.println(lists.get(i));
            Radioo.setText(lists.get(i));
            Radioo.setTextColor(Color.LTGRAY);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
                Radioo.setButtonTintList(ColorStateList.valueOf(RadioColor));
            Radioo.setOnClickListener(first_radio_listener);
            radioGroup.addView(Radioo);
        }

        int index = Preferences.loadPrefInt(featName, featNum);
        if (index > 0) { //Preventing it to get an index less than 1. below 1 = null = crash
            textView.setText(Html.fromHtml(featName + ": <font color='" + NumberTxtColor + "'>" + lists.get(index - 1)));
            ((RadioButton) radioGroup.getChildAt(index)).setChecked(true);
        }

        return radioGroup;
    }

    private void Collapse(LinearLayout linLayout, final String text) {
        LinearLayout.LayoutParams layoutParamsLL = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParamsLL.setMargins(0, 5, 0, 0);

        LinearLayout collapse = new LinearLayout(this);
        collapse.setLayoutParams(layoutParamsLL);
        collapse.setVerticalGravity(16);
        collapse.setOrientation(LinearLayout.VERTICAL);

        final LinearLayout collapseSub = new LinearLayout(this);
        collapseSub.setVerticalGravity(16);
        collapseSub.setPadding(0, 5, 0, 5);
        collapseSub.setOrientation(LinearLayout.VERTICAL);
        collapseSub.setBackgroundColor(Color.parseColor("#222D38"));
        collapseSub.setVisibility(View.GONE);
        mCollapse = collapseSub;

        final TextView textView = new TextView(this);
        textView.setBackgroundColor(CategoryBG);
        textView.setText("▽ " + text + " ▽");
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(TEXT_COLOR_2);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(0, 20, 0, 20);
        textView.setOnClickListener(new View.OnClickListener() {
				boolean isChecked;

				@Override
				public void onClick(View v) {

					boolean z = !this.isChecked;
					this.isChecked = z;
					if (z) {
						collapseSub.setVisibility(View.VISIBLE);
						textView.setText("△ " + text + " △");
						return;
					}
					collapseSub.setVisibility(View.GONE);
					textView.setText("▽ " + text + " ▽");
				}
			});
        collapse.addView(textView);
        collapse.addView(collapseSub);
        linLayout.addView(collapse);
    }

    private View Category(String text) {
        TextView textView = new TextView(this);
        textView.setBackgroundColor(CategoryBG);
        textView.setText(Html.fromHtml(text));
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(TEXT_COLOR_2);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(0, 5, 0, 5);
        return textView;
    }

    private View RichTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(Html.fromHtml(text));
        textView.setTextColor(TEXT_COLOR_2);
        textView.setPadding(10, 5, 10, 5);
        return textView;
    }

    private View RichWebView(String text) {
        WebView wView = new WebView(this);
        wView.loadData(text, "text/html", "utf-8");
        wView.setBackgroundColor(0x00000000); //Transparent
        wView.setPadding(0, 5, 0, 5);
        wView.getSettings().setAppCacheEnabled(false);
        return wView;
    }

    private void InjectBtn(final LinearLayout l) {
        l.removeAllViews();

        // ── Branding header ──────────────────────────────────────────
        TextView brand = new TextView(this);
        brand.setText("Anodize Mods");
        brand.setGravity(Gravity.CENTER);
        brand.setTextSize(20.0f);
        brand.setTextColor(Color.parseColor("#7C4DFF"));
        brand.setTypeface(null, Typeface.BOLD);
        brand.setPadding(0, 16, 0, 2);
        l.addView(brand);

        TextView sub = new TextView(this);
        sub.setText("War Robots • Root Edition");
        sub.setGravity(Gravity.CENTER);
        sub.setTextSize(11.0f);
        sub.setTextColor(Color.parseColor("#9E9E9E"));
        sub.setPadding(0, 0, 0, 14);
        l.addView(sub);

        // ── Divider ──────────────────────────────────────────────────
        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(MATCH_PARENT, 1));
        divider.setBackgroundColor(Color.parseColor("#2A2A4A"));
        l.addView(divider);

        // ── Status label ─────────────────────────────────────────────
        final TextView status = new TextView(this);
        status.setText("Ready — tap Inject to launch War Robots and patch");
        status.setGravity(Gravity.CENTER);
        status.setTextSize(12.0f);
        status.setTextColor(Color.parseColor("#B0B0B0"));
        status.setPadding(14, 14, 14, 6);
        l.addView(status);

        // ── Single inject button ──────────────────────────────────────
        final Button injectBtn = new Button(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT);
        lp.setMargins(20, 10, 20, 20);
        injectBtn.setLayoutParams(lp);
        injectBtn.setText("⚡  Launch & Inject");
        injectBtn.setTextColor(Color.WHITE);
        injectBtn.setTextSize(15.0f);
        injectBtn.setAllCaps(false);
        injectBtn.setTypeface(null, Typeface.BOLD);

        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setShape(GradientDrawable.RECTANGLE);
        btnBg.setCornerRadius(12f);
        btnBg.setColor(Color.parseColor("#7C4DFF"));
        injectBtn.setBackground(btnBg);

        injectBtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					injectBtn.setEnabled(false);
					injectBtn.setText("Launching War Robots…");
					status.setTextColor(Color.parseColor("#FFD740"));
					status.setText("Starting War Robots, please wait…");

					// Launch War Robots
					try {
						android.content.Intent launchIntent =
							getPackageManager().getLaunchIntentForPackage(targetPackage);
						if (launchIntent != null) {
							launchIntent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
							startActivity(launchIntent);
						}
					} catch (Exception e) {
						status.setText("Could not launch War Robots — is it installed?");
						status.setTextColor(Color.RED);
						injectBtn.setEnabled(true);
						injectBtn.setText("⚡  Launch & Inject");
						return;
					}

					// Final references for use inside nested anonymous classes
					final Button finalInjectBtn = injectBtn;
					final TextView finalStatus = status;

					// Wait for game process then inject
					new Thread(new Runnable() {
							@Override
							public void run() {
								// Give the game a moment to start its process
								try { Thread.sleep(3500); } catch (InterruptedException ignored) {}

								final boolean injected = InjectRoot(LibName);
								final boolean connected = injected && IsConnected();

								new Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
										@Override
										public void run() {
											if (injected && connected) {
												finalStatus.setText("✓ Injected successfully");
												finalStatus.setTextColor(Color.parseColor("#69F0AE"));
												featureList(getFeatureList(), patches);
											} else {
												finalStatus.setText("✗ Injection failed — make sure War Robots is running and Magisk root is active");
												finalStatus.setTextColor(Color.RED);
												finalInjectBtn.setEnabled(true);
												finalInjectBtn.setText("⚡  Retry Inject");
											}
										}
									});
							}
						}).start();
				}
			});

        l.addView(injectBtn);
    }

    public static int getProcessID(String pkg) {

        int pid = -1;
        if (Shell.rootAccess()) {
            String cmd = "for p in /proc/[0-9]*; do [[ $(<$p/cmdline) = " + pkg + " ]] && echo ${p##*/}; done";
            List<String> outs = new ArrayList<>();
            Shell.su(cmd).to(outs).exec();
            if (outs.size() > 0) {
                pid = Integer.parseInt(outs.get(0));
            }
        } else {
            Shell.Result out = Shell.sh("/system/bin/ps -A | grep \"" + pkg + "\"").exec();
            List<String> output = out.getOut();
            if (output.isEmpty() || output.get(0).contains("bad pid")) {
                out = Shell.sh("/system/bin/ps | grep \"" + pkg + "\"").exec();
                output = out.getOut();
                if (!output.isEmpty() && !output.get(0).contains("bad pid")) {
                    for (int i = 0; i < output.size(); i++) {
                        String[] results = output.get(i).trim().replaceAll("( )+", ",").replaceAll("(\n)+", ",").split(",");
                        if (results[8].equals(pkg)) {
                            pid = Integer.parseInt(results[1]);
                        }
                    }
                }
            } else {
                for (int i = 0; i < output.size(); i++) {
                    String[] results = output.get(i).trim().replaceAll("( )+", ",").replaceAll("(\n)+", ",").split(",");
                    for (int j = 0; j < results.length; j++) {
                        if (results[j].equals(pkg)) {
                            pid = Integer.parseInt(results[j - 7]);
                        }
                    }
                }
            }
        }
        return pid;
    }

    private boolean InjectRoot(String Lib) {
        try {
            String target = targetPackage;
            String injector = this.getApplicationInfo().nativeLibraryDir + File.separator + "libGlobalInject.so";
            String payload_source = this.getApplicationInfo().nativeLibraryDir + File.separator + Lib;
            String payload_dest = "/data/local/tmp/" + Lib;

            // Detect SELinux context from a known system lib
            String context = "u:object_r:system_lib_file:s0";
            List<String> STDOUT = new ArrayList<>();
            Shell.su("ls -lZ /system/lib/libandroid_runtime.so").to(STDOUT).exec();
            if (STDOUT.isEmpty()) {
                // Try 64-bit path
                Shell.su("ls -lZ /system/lib64/libandroid_runtime.so").to(STDOUT).exec();
            }
            for (String line : STDOUT) {
                if (line.contains(" u:object_r:") && line.contains(":s0")) {
                    String tmp = line.substring(line.indexOf("u:object_r:"));
                    int spaceIdx = tmp.indexOf(' ');
                    context = spaceIdx > 0 ? tmp.substring(0, spaceIdx) : tmp;
                    break;
                }
            }

            // Copy payload and set permissions
            Shell.su("cp " + payload_source + " " + payload_dest).exec();
            Shell.su("chmod 777 " + payload_dest).exec();
            Shell.su("chcon " + context + " " + payload_dest).exec();

            // Wait for game process with a 15-second timeout instead of infinite loop
            int waited = 0;
            int pid = getProcessID(target);
            while (pid <= 0 && waited < 15000) {
                Thread.sleep(500);
                waited += 500;
                pid = getProcessID(target);
            }
            if (pid <= 0) {
                return false; // Game never started
            }

            // Small settle delay after process appears
            Thread.sleep(1500);
            pid = getProcessID(target); // Re-fetch in case it changed

            String command = String.format(Locale.ENGLISH, "%s %d %s", injector, pid, payload_dest);
            Shell.su(command).exec();
            // Give the injected lib time to start its socket server before connecting
            Thread.sleep(1500);
            // Retry Init() up to 5 times — the socket server may not be ready instantly
            for (int attempt = 0; attempt < 5; attempt++) {
                try {
                    Init();
                    break;
                } catch (Exception ignored) {
                    Thread.sleep(500);
                }
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    /*    private boolean InjectVirtual(String Lib) {
	 try {
	 String target = targetPackage;
	 String injector = this.getApplicationInfo().nativeLibraryDir + File.separator + "libVirtualInject.so";
	 String payload_source = this.getApplicationInfo().nativeLibraryDir + File.separator + Lib;
	 String payload_dest = "/data/local/tmp/"+Lib;
	 String context = "u:object_r:system_lib_file:s0";
	 List<String> STDOUT = new ArrayList<>();
	 Shell.su("ls -lZ /system/lib/libandroid_runtime.so").to(STDOUT).exec();
	 for (String line : STDOUT) {
	 if (line.contains(" u:object_r:") && line.contains(":s0 ")) {
	 context = line.substring(line.indexOf("u:object_r:"));
	 context = context.substring(0, context.indexOf(' '));
	 }
	 }
	 Shell.su("cp " + payload_source + " " + payload_dest).exec();
	 Shell.su("chmod 777 " + payload_dest).exec();
	 Shell.su("chcon " + context + " " + payload_dest).exec();
	 while (getProcessID(target) <= 0) {}
	 Thread.sleep(1000);
	 int pid = getProcessID(target);
	 String command = String.format(Locale.ENGLISH,"%s %d %s", injector, pid, payload_dest);
	 Shell.su(command).exec();
	 Init();
	 return true;
	 } catch (Exception e) {
	 e.printStackTrace();
	 return false;
	 }

	 }*/
    //Override our Start Command so the Service doesnt try to recreate itself when the App is closed
    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }

    private boolean isViewCollapsed() {
        return rootFrame == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Check if we are still in the game. If now our menu and menu button will dissapear
    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    //Destroy our View
    public void onDestroy() {
        super.onDestroy();
        if (rootFrame != null) {
            mWindowManager.removeView(rootFrame);
        }
    }

    //Same as above so it wont crash in the background and therefore use alot of Battery life
    public void onTaskRemoved(Intent intent) {
        super.onTaskRemoved(intent);
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        stopSelf();
    }

    private void Thread() {
        if (rootFrame == null) {
            return;
        }
    }

    private class EditTextString {
        private String text;

        public void setString(String s) {
            text = s;
        }

        public String getString() {
            return text;
        }
    }

    private class EditTextNum {
        private int val;

        public void setNum(int i) {
            val = i;
        }

        public int getNum() {
            return val;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
