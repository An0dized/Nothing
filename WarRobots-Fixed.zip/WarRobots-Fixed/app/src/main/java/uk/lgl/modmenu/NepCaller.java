package uk.lgl.modmenu;

import android.app.Application;
import com.topjohnwu.superuser.Shell;

public class NepCaller extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Shell.getShell();
        Shell.su("setenforce 0").exec();
    }
}
